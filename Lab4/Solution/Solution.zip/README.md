# Project Overview
This project is to create responsive web design using different technique including:
* Flex box
* Media queries
## Team Members
| Name |
|--------|
| Some name |
| Another name |
## Screenshots
### Excercise B
![Excercise B final output](./ExerciseB.gif)
### Excercise C
![Excercise C final output](./ExerciseC.gif)